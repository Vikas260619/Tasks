import { createTheme } from "@material-ui/core";

export const theme = createTheme({
    palette: {
        primary: {
            main: '#3578f0'
        },
        secondary: {
            main: '#3d5569'
        }
    },
    typography: {
        h1: {
            fontSize: '3rem',
            color: '#FFF'
        },
        h2: {
            fontSize: '2.5rem'
        },
        h3: {
            fontSize: '2rem'
        },
        h4: {
            fontSize: '1.5rem'
        },
        h5: {
            fontSize: '1.2rem',
            color: '#FFF',
            marginLeft: "10px"
        },
        h6: {
            fontSize: '14px'
        },
    
    }
}) 