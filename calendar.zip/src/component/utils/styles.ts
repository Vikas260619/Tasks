import { makeStyles } from "@material-ui/core";

export const useStyles = makeStyles((theme) => ({
    box: {
      backgroundColor: theme.palette.primary.main,
      flexGrow: 1,
      boxShadow: "5px 5px 15px 5px #C5C5C5",
    },
    darkbox: {
      backgroundColor: '#3d5569'
    },
    main: {
      textAlign: "start",
      padding: "20px",
    },
    root: {
      width: "100%",
      borderBottom: "none",
    },
    container: {
      maxHeight: 440,
    },
    headrow: {
      "& th": {
        fontWeight: 700,
        textAlign: 'center',
        backgroundColor: '#C3C8D3'
      },
      "& tr ": {
        borderBottom: "none",
      },
    },
    bodyRow: {
      "& td": {
        fontWeight: 700,
        textAlign: 'center'
      },
    },
    week1: {
      marginLeft: "10px",
    },
    buttonbg: {
      background: "#fff",
      "& i": {
        color: "#000",
        fontWeight: 800,
      },
    },
    currentDate: {
      backgroundColor: '#3578f0',
      outline: '5px solid #3578f0',
      color: "#fff",
      border: '5px solid #fff'
    },
    darkCurrentDate: {
      backgroundColor: '#3d5569',
      outline: '5px solid #3d5569',
      color: "#fff",
      border: '5px solid #fff'
    },
    currentMonthDate: {
      color: "grey",
      backgroundColor: "#C3C8D3",
    },
    otherDates: {
      backgroundColor: "#C3C8D3",
      borderBottom: "none",
    },
    clickDate: {
      border: "5px solid #3578f0",
    },
    darkClickDate: {
      border: "5px solid #3d5569"
    },
  }));