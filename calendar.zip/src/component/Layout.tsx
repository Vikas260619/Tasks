import { Box } from "@material-ui/core";
import React from "react";
import { makeStyles } from '@material-ui/core/styles';


interface Props {
  children: React.ReactNode;
}
const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
      padding: theme.spacing(12, 20),
      background: 'whitesmoke'
    },
  
}))

const Layout: React.FunctionComponent<Props> = (props: Props) => {
    const classes = useStyles();
  return (
    <div className={classes.root}>
    <Box component="span" m={1} >
      <div id="page-content-wrapper">{props.children}</div>
    </Box>
    </div>
  );
};

export default Layout;
