import {
  Box,
  Button,
  ButtonGroup,
  Grid,
  Switch,
  Typography,
} from "@material-ui/core";
import Layout from "../Layout";
import { useDate } from "../../Hooks/Timer";
import { Divider } from "@material-ui/core";
import React, { useEffect, useState } from "react";
import Paper from "@material-ui/core/Paper";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import moment from "moment";
import { useStyles } from "../utils/styles";

const Calendar: React.FunctionComponent = () => {
  const classes = useStyles();
  const { time, todayDate } = useDate();
  const [checked, setChecked] = useState(false);
  const current = moment(new Date()).format("YYYY-MM-DD");
  const [curruntDate, setCurrentDate] = useState<any[]>([]);
  const [date, setDate] = useState(current);
  const [clickeddate, setclickedDate] = useState(null);
  const [selectedDate, setSelectedDate] = useState("Today");

  const switchHandler = (e: any) => {
    if (e.target.checked) {
      setChecked(e.target.checked);
    } else {
      setChecked(e.target.checked);
    }
  };

  useEffect(() => {
    initialWeekDays("current");
  }, []);

  const initialWeekDays = (val: any) => {
    val === "next"
      ? startEndWeek(7, 13)
      : val === "prev"
      ? startEndWeek(-7, -1)
      : val === "current"
      ? startEndWeek(0, 6)
      : startEndWeek(0, 6);
  };

  const startEndWeek = (fromStartWeek: any, fromEndWeek: any) => {
    let startWeek = moment(date).weekday(fromStartWeek).format("YYYY-MM-DD");
    let endWeek = moment(date).weekday(fromEndWeek).format("YYYY-MM-DD");
    setDate(startWeek);
    weekDays(startWeek, endWeek);
  };

  const weekDays = async (startWeek: any, endWeek: any) => {
    let calendar: any = [];

    for (var week: any = startWeek; week < endWeek; week++) {
      calendar.push({
        week: week,
        days: Array(7)
          .fill(0)
          // eslint-disable-next-line no-loop-func
          .map((n, i) =>
            moment(startWeek, "YYYY-MM-DD")
              .week(week)
              .startOf("week")
              .clone()
              .add(n + i, "day")
          ),
      });
    }
    setCurrentDate(calendar);
  };

  const onCellClick = (e: any) => {
    setclickedDate(e.target.textContent);
    const selectDate = curruntDate[0].days.filter(
      (item: any) => moment(item).format("DD") == e.target.textContent
    );
    setSelectedDate(selectDate);
  };

  return (
    <Layout>
      <Switch
        color="secondary"
        checked={checked}
        onChange={(e) => switchHandler(e)}
      />
      <Box className={!checked ? classes.box : classes.darkbox}>
        <Grid className={classes.main}>
          <Typography variant="h1" component={"h1"}>
            {time}
          </Typography>
          <Typography variant="h5" component={"h5"}>
            {todayDate}
          </Typography>
        </Grid>
        <Divider />
        <Grid container className={classes.main}>
          <Grid item md={4}>
            <Typography variant="h5" component={"h5"}>
              {moment(date).format("MMM-YYYY")}
            </Typography>
          </Grid>
          <Grid item md={6}>
            <Typography className={classes.week1} variant="h5" component={"h5"}>
              Weekly Calendar
            </Typography>
          </Grid>
          <Grid item md={2}>
            <ButtonGroup
              className={classes.buttonbg}
              variant="contained"
              color="primary"
            >
              <Button
                className={classes.buttonbg}
                onClick={(e) => initialWeekDays("prev")}
              >
                <i className="fa fa-angle-left " aria-hidden="true"></i>
              </Button>
              <Button
                className={classes.buttonbg}
                onClick={(e) => initialWeekDays("next")}
              >
                <i className="fa fa-angle-right" aria-hidden="true"></i>
              </Button>
            </ButtonGroup>
          </Grid>
        </Grid>
        <Grid>
          <Paper className={classes.root}>
            <TableContainer className={classes.container}>
              <Table stickyHeader aria-label="sticky table">
                <TableHead>
                  <TableRow className={classes.headrow}>
                    <TableCell>Sun</TableCell>
                    <TableCell>Mon</TableCell>
                    <TableCell>Tue</TableCell>
                    <TableCell>Wed</TableCell>
                    <TableCell>Thu</TableCell>
                    <TableCell>Fri</TableCell>
                    <TableCell>Sat</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  <TableRow className={classes.bodyRow}>
                    {curruntDate &&
                      curruntDate.map((item: any) =>
                        item.days.map((dates: any) => (
                          <TableCell
                            onClick={onCellClick}
                            key={dates}
                            className={
                              moment(dates).format("YYYY-MM-DD") === current &&
                              !checked
                                ? classes.currentDate
                                : moment(dates).format("YYYY-MM-DD") ===
                                    current && checked
                                ? classes.darkCurrentDate
                                : moment(dates).format("MM") !==
                                  moment(date).format("MM")
                                ? classes.currentMonthDate
                                : moment(dates).format("DD") == clickeddate &&
                                  !checked
                                ? classes.clickDate
                                : moment(dates).format("DD") == clickeddate &&
                                  checked
                                ? classes.darkClickDate
                                : classes.otherDates
                            }
                          >
                            {moment(dates).format("DD")}
                          </TableCell>
                        ))
                      )}
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </Paper>
        </Grid>
      </Box>
      <Box>
        <Typography
          style={{ color: "#000", float: "left", marginTop: "20px" }}
          variant="h5"
          component={"h5"}
        >
          {selectedDate !== "Today"
            ? moment(selectedDate[0]).format("dddd DD MMM")
            : "Today"}
        </Typography>
      </Box>
    </Layout>
  );
};

export default Calendar;
