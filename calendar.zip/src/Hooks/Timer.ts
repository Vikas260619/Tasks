import moment from "moment";
import React from "react";
export const useDate = () => {
  const [today, setDate] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => {
      setDate(new Date());
    }, 1000);
    return () => {
      clearInterval(timer);
    };
  }, []);

  const time = moment(today).format("h:mm:s");
  const todayDate = moment(today).format("DD-MMM-YYYY");
  return {
    time,
    todayDate,
  };
};
