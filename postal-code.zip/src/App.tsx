import Index from "./componets/Index";
import "./App.css";

export default function App() {
  return (
    <div className="App">
      <Index />
    </div>
  );
}