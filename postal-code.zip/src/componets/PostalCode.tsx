import { FC } from "react";
import { useForm } from "../useForm";
import "./PostalCode.scss";

interface User {
  postalCode: number;
}

const PostalCode: FC = () => {
  const { handleSubmit, handleChange, data: user, errors } = useForm<User>({
    validations: {
      postalCode: {
        pattern: {
          value: "(^d{5}$)|(^d{5}-d{4}$)",
          message: "Please enter only digits"
        },
        custom: {
          isValid: (value: any) => value.length === 5,
          message: "The password needs to be at least 5 characters long."
        }
      }
    },
    onSubmit: () => alert("User submitted!")
  });

  return (
    <form className="postalcode-wrapper" onSubmit={handleSubmit}>
      <h1>America Zip code</h1>
      <input
        placeholder="Potal code*"
        value={user.postalCode}
        onChange={handleChange("postalCode")}
        required
      />
      {errors.postalCode && <p className="error">{errors.postalCode}</p>}
      <button type="submit" className="submit">
        Submit
      </button>
    </form>
  );
};

export default PostalCode;
