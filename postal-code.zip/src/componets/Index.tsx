import React from "react";
import PostalCode from "./PostalCode";

function Index() {
  return (
    <div className="App">
      <PostalCode />
    </div>
  );
}

export default Index;
